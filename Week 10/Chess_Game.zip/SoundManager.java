import javax.sound.sampled.*;
import java.io.File;

public class SoundManager {
    private static Clip backgroundClip;

    public static void playBackground() {
        try {
            stopBackground();
            AudioInputStream audio = AudioSystem.getAudioInputStream(new File("sounds/background.wav"));
            backgroundClip = AudioSystem.getClip();
            backgroundClip.open(audio);
            backgroundClip.loop(Clip.LOOP_CONTINUOUSLY);
            backgroundClip.start();
        } catch (Exception e) {
            System.out.println("Background music error: " + e.getMessage());
        }
    }

    public static void stopBackground() {
        if (backgroundClip != null) {
            backgroundClip.stop();
            backgroundClip.close();
            backgroundClip = null;
        }
    }

    public static void play(String file) {
        try {
            AudioInputStream audio = AudioSystem.getAudioInputStream(new File(file));
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.addLineListener(event -> {
                if (event.getType() == LineEvent.Type.STOP) {
                    clip.close();
                }
            });
            clip.start();
        } catch (Exception e) {
            System.out.println("Sound error: " + e.getMessage());
        }
    }

    public static void playMove() { play("sounds/move.wav"); }
    public static void playCapture() { play("sounds/capture.wav"); }
    public static void playCheck() { play("sounds/check.wav"); }
    public static void playCheckmate() { play("sounds/checkmate.wav"); }
}
