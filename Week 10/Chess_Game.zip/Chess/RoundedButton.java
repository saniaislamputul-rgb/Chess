import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

/**
 * A JButton painted as a rounded, wood/maroon-themed button with a gold border,
 * used for the Play-screen and Pause-menu buttons so the whole app shares one look.
 */
public class RoundedButton extends JButton {

    private static final Color GOLD = new Color(212, 175, 100);
    private Color base;
    private Color baseHover;
    private Color baseSelected;
    private boolean selected = false;

    public RoundedButton(String text) {
        this(text, new Color(94, 48, 40));
    }

    public RoundedButton(String text, Color base) {
        super(text);
        this.base = base;
        this.baseHover = base.brighter();
        this.baseSelected = new Color(160, 40, 40);
        setFont(new Font("SansSerif", Font.BOLD, 16));
        setForeground(new Color(245, 230, 200));
        setFocusPainted(false);
        setContentAreaFilled(false);
        setBorderPainted(false);
        setOpaque(false);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    public void setSelectedStyle(boolean selected) {
        this.selected = selected;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth(), h = getHeight();
        RoundRectangle2D shape = new RoundRectangle2D.Float(1, 1, w - 3, h - 3, 18, 18);

        Color fill = selected ? baseSelected : (getModel().isRollover() ? baseHover : base);
        if (getModel().isPressed()) fill = fill.darker();

        GradientPaint gp = new GradientPaint(0, 0, fill.brighter(), 0, h, fill.darker());
        g2.setPaint(gp);
        g2.fill(shape);

        g2.setColor(GOLD);
        g2.setStroke(new BasicStroke(2f));
        g2.draw(shape);

        g2.dispose();
        super.paintComponent(g);
    }
}